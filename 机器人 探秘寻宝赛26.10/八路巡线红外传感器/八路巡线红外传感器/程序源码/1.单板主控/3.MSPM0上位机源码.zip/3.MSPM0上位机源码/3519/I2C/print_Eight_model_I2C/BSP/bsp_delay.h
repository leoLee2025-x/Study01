#ifndef __BSP_DELAY_H_
#define __BSP_DELAY_H_


#include "ti_msp_dl_config.h"
#include "AllHeader.h"

void delay_ms(unsigned int ms);



#endif
