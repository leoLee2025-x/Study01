#ifndef _APP_IRTRACKING_H_
#define _APP_IRTRACKING_H_


#include "AllHeader.h"


void printf_LineWalking(void);
void APP_IRR_PID_Init(void);

#endif

