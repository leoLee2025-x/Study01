#include "app_irtracking.h"

//Ѳ��̽ͷ�Ĵ���
static void track_deal_four(u8 *s1,u8 *s2,u8 *s3,u8 *s4,u8 *s5,u8 *s6,u8 *s7,u8 *s8)
{
	*s1 = DL_GPIO_readPins(IR_X_X1_PORT, IR_X_X1_PIN) > 0 ? 1 : 0;;
	*s2 = DL_GPIO_readPins(IR_X_X2_PORT, IR_X_X2_PIN) > 0 ? 1 : 0;;
	*s3 = DL_GPIO_readPins(IR_X_X3_PORT, IR_X_X3_PIN) > 0 ? 1 : 0;;
	*s4 = DL_GPIO_readPins(IR_X_X4_PORT, IR_X_X4_PIN) > 0 ? 1 : 0;;
	
	*s5 = DL_GPIO_readPins(IR_X_X5_PORT, IR_X_X5_PIN) > 0 ? 1 : 0;;
	*s6 = DL_GPIO_readPins(IR_X_X6_PORT, IR_X_X6_PIN) > 0 ? 1 : 0;;
	*s7 = DL_GPIO_readPins(IR_X_X7_PORT, IR_X_X7_PIN) > 0 ? 1 : 0;;
	*s8 = DL_GPIO_readPins(IR_X_X8_PORT, IR_X_X8_PIN) > 0 ? 1 : 0;;
}





//x1-x8 ����������
void printf_LineWalking(void)
{
	static int8_t err = 0;
	static u8 x1,x2,x3,x4,x5,x6,x7,x8;
	
	track_deal_four(&x1,&x2,&x3,&x4,&x5,&x6,&x7,&x8);

	static char bufbuf[30]={'\0'};
	sprintf(bufbuf,"%d\t %d\t %d\t %d\t %d\t %d\t %d\t %d\t \r\n",x1,x2,x3,x4,x5,x6,x7,x8);
	uart0_send_string((char*)bufbuf);

}




